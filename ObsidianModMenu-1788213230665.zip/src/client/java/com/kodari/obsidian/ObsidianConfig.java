package com.kodari.obsidian;

import dev.isxander.yacl3.api.ConfigCategory;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.api.OptionGroup;
import dev.isxander.yacl3.api.YetAnotherConfigLib;
import dev.isxander.yacl3.api.controller.IntegerSliderControllerBuilder;
import dev.isxander.yacl3.api.controller.TickBoxControllerBuilder;
import dev.isxander.yacl3.config.v2.api.ConfigClassHandler;
import dev.isxander.yacl3.config.v2.api.SerialEntry;
import dev.isxander.yacl3.config.v2.api.serializer.GsonConfigSerializerBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.nio.file.Path;

public class ObsidianConfig {
    public static final ConfigClassHandler<ObsidianConfig> HANDLER =
            ConfigClassHandler.createBuilder(ObsidianConfig.class)
                    .id(Identifier.of(ObsidianMod.MOD_ID, "config"))
                    .serializer(config -> GsonConfigSerializerBuilder.create(config)
                            .setPath(Path.of("config", "obsidian-mod-menu.json"))
                            .build())
                    .build();

    @SerialEntry
    public boolean showVersions = true;

    @SerialEntry
    public boolean showDescriptions = true;

    @SerialEntry
    public boolean largeTouchTargets = true;

    @SerialEntry
    public int rowSpacing = 4;

    public static ObsidianConfig get() {
        return HANDLER.instance();
    }

    public static void load() {
        HANDLER.load();
    }

    public static void save() {
        HANDLER.save();
    }

    public static Screen createScreen(Screen parent) {
        ObsidianConfig config = get();

        Option<Boolean> descriptions = Option.<Boolean>createBuilder()
                .name(Text.translatable("obsidianmodmenu.config.show_descriptions"))
                .description(OptionDescription.of(Text.translatable("obsidianmodmenu.config.show_descriptions.description")))
                .binding(true, () -> config.showDescriptions, value -> config.showDescriptions = value)
                .controller(TickBoxControllerBuilder::create)
                .build();

        return YetAnotherConfigLib.createBuilder()
                .title(Text.translatable("obsidianmodmenu.config.title"))
                .category(ConfigCategory.createBuilder()
                        .name(Text.translatable("obsidianmodmenu.config.general"))
                        .group(OptionGroup.createBuilder()
                                .name(Text.translatable("obsidianmodmenu.config.display"))
                                .option(Option.<Boolean>createBuilder()
                                        .name(Text.translatable("obsidianmodmenu.config.show_versions"))
                                        .description(OptionDescription.of(Text.translatable("obsidianmodmenu.config.show_versions.description")))
                                        .binding(true, () -> config.showVersions, value -> config.showVersions = value)
                                        .controller(TickBoxControllerBuilder::create)
                                        .build())
                                .option(descriptions)
                                .option(Option.<Boolean>createBuilder()
                                        .name(Text.translatable("obsidianmodmenu.config.large_touch_targets"))
                                        .description(OptionDescription.of(Text.translatable("obsidianmodmenu.config.large_touch_targets.description")))
                                        .binding(true, () -> config.largeTouchTargets, value -> config.largeTouchTargets = value)
                                        .controller(TickBoxControllerBuilder::create)
                                        .build())
                                .option(Option.<Integer>createBuilder()
                                        .name(Text.translatable("obsidianmodmenu.config.row_spacing"))
                                        .description(OptionDescription.of(Text.translatable("obsidianmodmenu.config.row_spacing.description")))
                                        .binding(4, () -> config.rowSpacing, value -> config.rowSpacing = value)
                                        .controller(option -> IntegerSliderControllerBuilder.create(option).range(0, 12).step(1))
                                        .build())
                                .build())
                        .build())
                .build()
                .generateScreen(parent);
    }
}