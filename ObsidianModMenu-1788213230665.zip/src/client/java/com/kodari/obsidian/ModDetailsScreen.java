package com.kodari.obsidian;

import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

public class ModDetailsScreen extends Screen {
    private final Screen parent;
    private final ModContainer mod;

    public ModDetailsScreen(Screen parent, ModContainer mod) {
        super(Text.literal(mod.getMetadata().getName()));
        this.parent = parent;
        this.mod = mod;
    }

    @Override
    protected void init() {
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.back"), button -> this.client.setScreen(this.parent))
                .dimensions(this.width / 2 - 62, this.height - 38, 124, 24)
                .build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 24, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal(mod.getMetadata().getId() + " • " + mod.getMetadata().getVersion().getFriendlyString()),
                this.width / 2, 44, 0xFFBBA6E8);

        List<OrderedText> lines = this.textRenderer.wrapLines(Text.literal(mod.getMetadata().getDescription()), this.width - 56);
        int y = 78;
        for (OrderedText line : lines) {
            context.drawTextWithShadow(this.textRenderer, line, 28, y, 0xFFD6D6D6);
            y += 12;
        }
        super.render(context, mouseX, mouseY, delta);
    }
}