package com.kodari.obsidian;

import net.fabricmc.api.ClientModInitializer;

public class ObsidianModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ObsidianConfig.load();
    }
}