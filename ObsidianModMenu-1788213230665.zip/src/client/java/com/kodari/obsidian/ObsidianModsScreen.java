package com.kodari.obsidian;

import com.terraformersmc.modmenu.ModMenu;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class ObsidianModsScreen extends Screen {
    private final Screen parent;
    private final List<ModContainer> installedMods;
    private final List<ModRow> rows = new ArrayList<>();
    private TextFieldWidget searchField;
    private String query = "";
    private int scrollOffset;
    private int maxScroll;
    private boolean draggingList;
    private double lastDragY;

    public ObsidianModsScreen(Screen parent) {
        super(Text.translatable("obsidianmodmenu.screen.title"));
        this.parent = parent;
        this.installedMods = new ArrayList<>(FabricLoader.getInstance().getAllMods());
        this.installedMods.sort(Comparator.comparing(ObsidianModsScreen::displayName, String.CASE_INSENSITIVE_ORDER));
    }

    private static String displayName(ModContainer mod) {
        return mod.getMetadata().getName();
    }

    @Override
    protected void init() {
        this.searchField = new TextFieldWidget(this.client.textRenderer, 28, 35, this.width - 56, 28,
                Text.translatable("obsidianmodmenu.search"));
        this.searchField.setMaxLength(80);
        this.searchField.setText(this.query);
        this.searchField.setChangedListener(value -> {
            this.query = value;
            this.scrollOffset = 0;
            this.rebuildRows();
        });
        this.rebuildRows();
    }

    private void rebuildRows() {
        if (this.searchField == null) {
            return;
        }

        String search = this.query.trim().toLowerCase(Locale.ROOT);
        List<ModContainer> filtered = this.installedMods.stream()
                .filter(mod -> search.isEmpty()
                        || displayName(mod).toLowerCase(Locale.ROOT).contains(search)
                        || mod.getMetadata().getId().toLowerCase(Locale.ROOT).contains(search))
                .toList();

        int rowHeight = rowHeight();
        int listHeight = Math.max(0, this.height - 126);
        this.maxScroll = Math.max(0, filtered.size() * rowHeight - listHeight);
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScroll));

        this.clearChildren();
        this.addDrawableChild(this.searchField);
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("gui.back"), button -> closeScreen())
                .dimensions(this.width / 2 - 62, this.height - 34, 124, 24)
                .build());

        this.rows.clear();
        for (ModContainer mod : filtered) {
            ModRow row = new ModRow(mod, ModMenu.hasConfigScreen(mod.getMetadata().getId()));
            this.rows.add(row);
            this.addDrawableChild(row.configureButton);
            this.addDrawableChild(row.detailsButton);
        }
        layoutRows();
    }

    private int rowHeight() {
        return (ObsidianConfig.get().largeTouchTargets ? 70 : 58) + ObsidianConfig.get().rowSpacing;
    }

    private void layoutRows() {
        int top = 74;
        int bottom = this.height - 52;
        int rowHeight = rowHeight();
        for (int index = 0; index < this.rows.size(); index++) {
            ModRow row = this.rows.get(index);
            int y = top + index * rowHeight - this.scrollOffset;
            boolean visible = y + rowHeight > top && y < bottom;
            if (visible) {
                row.configureButton.setPosition(Math.max(28, this.width - 224), y + 20);
                row.detailsButton.setPosition(Math.max(28, this.width - 116), y + 20);
            } else {
                row.configureButton.setPosition(-1000, -1000);
                row.detailsButton.setPosition(-1000, -1000);
            }
        }
    }

    private void closeScreen() {
        this.client.setScreen(this.parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        layoutRows();

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFFFF);
        int top = 74;
        int bottom = this.height - 52;
        context.fill(20, top - 4, this.width - 20, bottom, 0xAA101014);

        context.enableScissor(20, top, this.width - 20, bottom);
        int rowHeight = rowHeight();
        for (int index = 0; index < this.rows.size(); index++) {
            ModRow row = this.rows.get(index);
            int y = top + index * rowHeight - this.scrollOffset;
            if (y + rowHeight <= top || y >= bottom) {
                continue;
            }

            context.fill(26, y, this.width - 26, y + rowHeight - ObsidianConfig.get().rowSpacing, 0xCC24242C);
            context.drawTextWithShadow(this.textRenderer, Text.literal(row.mod.getMetadata().getName()), 36, y + 8, 0xFFFFFFFF);
            context.drawTextWithShadow(this.textRenderer, Text.literal(row.mod.getMetadata().getId()), 36, y + 24, 0xFF9D9DA8);
            if (ObsidianConfig.get().showVersions) {
                context.drawTextWithShadow(this.textRenderer,
                        Text.literal(row.mod.getMetadata().getVersion().getFriendlyString()),
                        36, y + 40, 0xFFBBA6E8);
            }
            if (ObsidianConfig.get().showDescriptions && !ObsidianConfig.get().largeTouchTargets) {
                String description = row.mod.getMetadata().getDescription();
                if (!description.isBlank()) {
                    context.drawTextWithShadow(this.textRenderer,
                            Text.literal(description.length() > 42 ? description.substring(0, 42) + "..." : description),
                            36, y + 40, 0xFFD0D0D0);
                }
            }
        }
        context.disableScissor();

        Text result = Text.translatable("obsidianmodmenu.screen.count", this.rows.size());
        context.drawTextWithShadow(this.textRenderer, result, 28, this.height - 46, 0xFF9D9DA8);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseY >= 74 && mouseY <= this.height - 52 && this.maxScroll > 0) {
            this.scrollOffset -= (int) (verticalAmount * rowHeight());
            this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScroll));
            layoutRows();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) {
            return true;
        }
        if (click.y() >= 74 && click.y() <= this.height - 52) {
            this.draggingList = true;
            this.lastDragY = click.y();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonInfo button, double mouseX, double mouseY, double deltaX, double deltaY) {
        if (this.draggingList && this.maxScroll > 0) {
            this.scrollOffset -= (int) (mouseY - this.lastDragY);
            this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScroll));
            this.lastDragY = mouseY;
            layoutRows();
            return true;
        }
        return super.mouseDragged(button, mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        this.draggingList = false;
        return super.mouseReleased(click);
    }

    private final class ModRow {
        private final ModContainer mod;
        private final boolean hasConfig;
        private final ButtonWidget configureButton;
        private final ButtonWidget detailsButton;

        private ModRow(ModContainer mod, boolean hasConfig) {
            this.mod = mod;
            this.hasConfig = hasConfig;
            this.configureButton = ButtonWidget.builder(
                            !hasConfig ? Text.translatable("obsidianmodmenu.button.no_config")
                                    : Text.translatable("obsidianmodmenu.button.configure"),
                            button -> openConfig())
                    .dimensions(0, 0, 104, 24)
                    .build();
            this.detailsButton = ButtonWidget.builder(Text.translatable("obsidianmodmenu.button.details"),
                            button -> client.setScreen(new ModDetailsScreen(ObsidianModsScreen.this, mod)))
                    .dimensions(0, 0, 104, 24)
                    .build();
        }

        private void openConfig() {
            if (this.hasConfig) {
                Screen configScreen = ModMenu.getConfigScreen(this.mod.getMetadata().getId(), ObsidianModsScreen.this);
                if (configScreen != null) {
                    client.setScreen(configScreen);
                }
            }
        }
    }
}