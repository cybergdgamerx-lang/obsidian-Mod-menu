package com.kodari.obsidian.mixin.client;

import com.kodari.obsidian.ObsidianModsScreen;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Shadow
    protected int width;

    @Shadow
    protected int height;

    @Shadow
    protected abstract <T extends Element & Selectable & Drawable> T addDrawableChild(T drawableElement);

    @Inject(method = "init", at = @At("TAIL"))
    private void obsidian$addModsButton(CallbackInfo callbackInfo) {
        this.addDrawableChild(ButtonWidget.builder(Text.translatable("obsidianmodmenu.button.mods"),
                        button -> MinecraftClient.getInstance().setScreen(new ObsidianModsScreen((TitleScreen) (Object) this)))
                .dimensions(this.width / 2 - 100, this.height - 44, 200, 24)
                .build());
    }
}