package com.kodari.obsidian;

import net.fabricmc.api.ModInitializer;

public class ObsidianMod implements ModInitializer {
    public static final String MOD_ID = "obsidianmodmenu";

    @Override
    public void onInitialize() {
    }
}